package dev.tilegame.application;

import dev.tilegame.Editor;

public class LaunchEditor
{
	public static void main(String args[])
	{
		new Editor().start();
	}
}