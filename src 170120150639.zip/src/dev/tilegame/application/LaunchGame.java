package dev.tilegame.application;

import dev.tilegame.Game;

public class LaunchGame
{
	public static void main(String args[])
	{
		new Game("Autumn Park", 1366, 768).start();
	}
}