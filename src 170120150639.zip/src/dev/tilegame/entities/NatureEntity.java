package dev.tilegame.entities;

public abstract class NatureEntity extends Entity
{
	
	public NatureEntity()
	{
	}
}